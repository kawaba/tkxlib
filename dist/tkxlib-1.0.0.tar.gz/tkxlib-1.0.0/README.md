# tkxlib

`tkxlib` bundles two small helpers: `disp_image` for Pillow-powered Tkinter image animations and `kbinput` for defensive `input()` wrappers. Distribution archives are hosted at https://k-webs.jp/python/lib/.

## Installation

The project uses a `pyproject.toml`, so install it via the usual `pip` workflow:

```bash
pip install tkxlib
```

To install directly from the official mirror:

```bash
pip install https://k-webs.jp/python/lib/tkxlib-latest.zip
```

## Modules and public API

### `tkxlib.disp_image`

- `dispImg(image_path, display_time_ms, display_mode)`
- `dispImg_zoom(image_path)`
- `dispImg_zoom_rotate(image_path)`

These helpers open a temporary Tkinter window and animate the specified image via zooming and rotation effects.

### `tkxlib.kbinput`

Exports every helper defined in the module: `get_int`, `get_float`, `get_str`, `get_bool`, `get_list`, `get_list_int`, `get_list_float`, `get_tuple`, `get_tuple_int`, `get_tuple_float`, `get_set`, `get_set_int`, `get_set_float`, `get_dict`.

## Notes

- Requires Python 3.9 or newer.
- Depends on Pillow for image handling.
- `tkxlib/img` is included as package data so sample assets are bundled with wheels and sdists.
